# Frontend Design Documentation

## Overview

Restaurant Management System frontend built with **React 18 + TypeScript + Vite + Tailwind CSS**.

---

## Architecture

```
frontend/
├── src/
│   ├── api/           # API client functions
│   ├── components/    # Reusable UI components
│   ├── config/        # Configuration (API, routes)
│   ├── context/       # React Context providers
│   ├── pages/         # Page components by feature
│   │   ├── admin/     # Admin dashboard & management
│   │   ├── auth/      # Login, Register, Profile
│   │   ├── errors/    # Error pages (404, 401)
│   │   ├── kitchen/   # Kitchen display system
│   │   ├── menu/      # Customer menu browsing
│   │   └── order/     # Order management
│   └── utils/         # Helper functions (JWT, API)
└── docs/              # Documentation
```

---

## User Roles & Access

| Role | ID | Pages Accessible |
|------|-----|------------------|
| Customer | 1 | Menu, Order, Profile |
| Admin | 2 | All pages + Admin Dashboard |
| Kitchen | 3 | Kitchen Display, Menu (read-only) |

---

## Page Designs

### 1. Authentication Pages

#### Login (`/login`)
```
┌─────────────────────────────────────┐
│         Restaurant Logo             │
├─────────────────────────────────────┤
│  ┌─────────────────────────────┐    │
│  │ Email                       │    │
│  └─────────────────────────────┘    │
│  ┌─────────────────────────────┐    │
│  │ Password                    │    │
│  └─────────────────────────────┘    │
│                                     │
│  [         Login Button         ]   │
│                                     │
│  Don't have account? Register       │
└─────────────────────────────────────┘
```

**States:**
- Default: Empty form
- Loading: Button shows spinner
- Error: Red border on invalid fields + error message
- Success: Redirect to `/menu` (customer) or `/admin/dashboard` (admin)

#### Register (`/register`)
```
┌─────────────────────────────────────┐
│         Create Account              │
├─────────────────────────────────────┤
│  Full Name: [________________]      │
│  Email:     [________________]      │
│  Phone:     [________________]      │
│  Password:  [________________]      │
│  Role:      [Customer ▼     ]       │
│                                     │
│  [       Register Button        ]   │
│                                     │
│  Already have account? Login        │
└─────────────────────────────────────┘
```

---

### 2. Menu Page (`/menu`)

```
┌────────────────────────────────────────────────────────────┐
│  [Logo]  Menu    Orders    Profile    [Cart (3)]  [Logout] │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐          │
│  │   🍕        │ │   🍔        │ │   🍝        │          │
│  │  Pizza      │ │  Burger     │ │  Pasta      │          │
│  │  රු 1200    │ │  රු 800     │ │  රු 1000    │          │
│  │ [Add to Cart]│ │ [Add to Cart]│ │ [Add to Cart]│         │
│  └─────────────┘ └─────────────┘ └─────────────┘          │
│                                                            │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐          │
│  │   🥗        │ │   🍜        │ │   🍣        │          │
│  │  Salad      │ │  Noodles    │ │  Sushi Set  │          │
│  │  රු 600     │ │  රු 750     │ │  රු 2500    │          │
│  │ [Add to Cart]│ │ [Add to Cart]│ │ [Add to Cart]│         │
│  └─────────────┘ └─────────────┘ └─────────────┘          │
└────────────────────────────────────────────────────────────┘
```

**Components:**
- `Header` - Navigation with cart badge
- `MenuCard` - Individual menu item display
- `CartSidebar` - Slide-out cart panel

**Interactions:**
- Click "Add to Cart" → Item added, toast notification
- Click category filter → Filter menu items
- Click cart icon → Open cart sidebar

---

### 3. Cart Sidebar

```
┌─────────────────────────┐
│  Your Cart          [X] │
├─────────────────────────┤
│  Pizza                  │
│  Qty: [-] 2 [+]  රු 2400│
│  [Remove]               │
├─────────────────────────┤
│  Burger                 │
│  Qty: [-] 1 [+]  රු 800 │
│  [Remove]               │
├─────────────────────────┤
│  Subtotal:     රු 3200  │
│  Service (10%): රු 320  │
│  ─────────────────────  │
│  Total:        රු 3520  │
│                         │
│  [    Place Order     ] │
└─────────────────────────┘
```

---

### 4. Order Page (`/order`)

```
┌────────────────────────────────────────────────────────────┐
│                     Your Orders                            │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ Order #1234              Today, 2:30 PM            │   │
│  │ ─────────────────────────────────────────────────  │   │
│  │ 2x Pizza             රු 2400                       │   │
│  │ 1x Burger            රු 800                        │   │
│  │ ─────────────────────────────────────────────────  │   │
│  │ Total: රු 3520       Status: [PREPARING 🔄]       │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
│  ┌────────────────────────────────────────────────────┐   │
│  │ Order #1230              Today, 1:15 PM            │   │
│  │ 1x Pasta             රු 1000                       │   │
│  │ Total: රු 1100       Status: [DELIVERED ✅]        │   │
│  └────────────────────────────────────────────────────┘   │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

**Order Status Flow:**
`PENDING` → `PREPARING` → `READY` → `DELIVERED`

---

### 5. Kitchen Display (`/kitchen`)

```
┌────────────────────────────────────────────────────────────┐
│  Kitchen Display System                     [Auto-refresh] │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  PENDING (3)               PREPARING (2)                   │
│  ┌────────────┐           ┌────────────┐                  │
│  │ #1234      │           │ #1232      │                  │
│  │ Table 5    │           │ Table 3    │                  │
│  │ 2x Pizza   │           │ 1x Sushi   │                  │
│  │ 1x Burger  │           │ 2x Noodles │                  │
│  │ 5 min ago  │           │ 10 min ago │                  │
│  │[Start Prep]│           │[Mark Ready]│                  │
│  └────────────┘           └────────────┘                  │
│  ┌────────────┐           ┌────────────┐                  │
│  │ #1235      │           │ #1231      │                  │
│  │ Table 8    │           │ Table 1    │                  │
│  │ 1x Salad   │           │ 3x Pasta   │                  │
│  │ 2 min ago  │           │ 15 min ago │                  │
│  │[Start Prep]│           │[Mark Ready]│                  │
│  └────────────┘           └────────────┘                  │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

---

### 6. Admin Dashboard (`/admin/dashboard`)

```
┌────────────────────────────────────────────────────────────┐
│  Admin Dashboard                                           │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐       │
│  │ Today's      │ │ Active       │ │ Total        │       │
│  │ Revenue      │ │ Orders       │ │ Customers    │       │
│  │ රු 45,600    │ │ 12           │ │ 156          │       │
│  └──────────────┘ └──────────────┘ └──────────────┘       │
│                                                            │
│  Quick Actions:                                            │
│  [Menu Management] [Staff Management] [View Orders]        │
│                                                            │
│  Recent Orders:                                            │
│  ┌──────────────────────────────────────────────────┐     │
│  │ #1235 | Table 8 | රු 600   | PENDING    | 2min   │     │
│  │ #1234 | Table 5 | රු 3520  | PREPARING  | 5min   │     │
│  │ #1233 | Table 2 | රු 1500  | READY      | 8min   │     │
│  └──────────────────────────────────────────────────┘     │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

---

### 7. Admin Menu Management (`/admin/menu`)

```
┌────────────────────────────────────────────────────────────┐
│  Menu Management                          [+ Add New Item] │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ ID │ Name     │ Price  │ Category │ Status │ Actions │ │
│  ├──────────────────────────────────────────────────────┤ │
│  │ 1  │ Pizza    │ රු1200 │ Main     │ ✅     │ [E] [D] │ │
│  │ 2  │ Burger   │ රු800  │ Main     │ ✅     │ [E] [D] │ │
│  │ 3  │ Pasta    │ රු1000 │ Main     │ ❌     │ [E] [D] │ │
│  │ 4  │ Salad    │ රු600  │ Sides    │ ✅     │ [E] [D] │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                            │
│  Add/Edit Form:                                            │
│  ┌───────────────────────────────────────────────────┐    │
│  │ Name: [____________]  Price: [______]             │    │
│  │ Category: [Main ▼]    Description: [___________]  │    │
│  │ Image: [Choose File]  Available: [✓]              │    │
│  │                       [Save] [Cancel]             │    │
│  └───────────────────────────────────────────────────┘    │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

---

## Component Library

### Reusable Components

| Component | Location | Usage |
|-----------|----------|-------|
| `Header` | `components/Header.tsx` | Navigation bar with auth state |
| `Cart` | `components/Cart.tsx` | Cart sidebar with items |
| `ProtectedRoute` | `components/ProtectedRoute.tsx` | Auth check wrapper |
| `RoleProtectedRoute` | `components/RoleProtectedRoute.tsx` | Role-based access |
| `ErrorBoundary` | `components/ErrorBoundary.tsx` | Error handling wrapper |

### Design Tokens (Tailwind)

```css
/* Colors */
--primary: indigo-600
--primary-hover: indigo-700
--success: green-500
--error: red-500
--warning: yellow-500

/* Spacing */
padding-card: p-4
margin-section: mb-6
gap-grid: gap-6

/* Typography */
heading-1: text-2xl font-semibold
heading-2: text-xl font-medium
body: text-base
caption: text-sm text-gray-500
```

---

## State Management

### Context Providers

1. **AuthContext** - User authentication state
   - `user`, `isAuthenticated`, `login()`, `logout()`, `register()`

2. **CartContext** - Shopping cart state
   - `cartItems`, `addToCart()`, `removeFromCart()`, `clearCart()`, `getTotalPrice()`

3. **TableContext** - Selected table for ordering
   - `tableId`, `tableName`, `setTable()`

---

## User Flows

### Flow 1: Customer Ordering

```
Login → Select Table → Browse Menu → Add to Cart → Checkout → View Order Status
```

### Flow 2: Kitchen Processing

```
Login (Kitchen) → View Pending Orders → Start Preparing → Mark Ready
```

### Flow 3: Admin Management

```
Login (Admin) → Dashboard → Menu Management → Add/Edit Items
```

---

## Responsive Breakpoints

| Breakpoint | Width | Layout |
|------------|-------|--------|
| Mobile | < 640px | Single column, bottom nav |
| Tablet | 640-1024px | 2 column grid |
| Desktop | > 1024px | 3 column grid, sidebar |

---

## Testing Checklist

### Pages to Test

- [ ] Login with valid credentials
- [ ] Login with invalid credentials (error handling)
- [ ] Register new user
- [ ] View menu items
- [ ] Add items to cart
- [ ] Update cart quantities
- [ ] Remove items from cart
- [ ] Place order
- [ ] View order history
- [ ] Kitchen: View pending orders
- [ ] Kitchen: Update order status
- [ ] Admin: View dashboard stats
- [ ] Admin: Add new menu item
- [ ] Admin: Edit menu item
- [ ] Admin: Delete menu item
- [ ] Profile: View profile
- [ ] Profile: Update profile

---

## Next Steps

1. Implement real API calls (replace dummy data)
2. Add image upload for menu items
3. Add real-time order updates (WebSocket)
4. Add payment integration
5. Add analytics charts to admin dashboard
