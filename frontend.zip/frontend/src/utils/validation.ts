import { z } from 'zod';

/**
 * Login form validation schema
 */
export const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email'),
  password: z
    .string()
    .min(1, 'Password is required')
    .min(6, 'Password must be at least 6 characters'),
});

export type LoginFormData = z.infer<typeof loginSchema>;

/**
 * Registration form validation schema
 */
export const registerSchema = z.object({
  fullName: z
    .string()
    .min(1, 'Full name is required')
    .min(2, 'Name must be at least 2 characters')
    .max(100, 'Name cannot exceed 100 characters'),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email'),
  password: z
    .string()
    .min(1, 'Password is required')
    .min(8, 'Password must be at least 8 characters')
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      'Password must contain uppercase, lowercase, and a number'
    ),
  phone: z
    .string()
    .optional()
    .refine(
      (val) => !val || /^\+?[0-9]{10,15}$/.test(val),
      'Please enter a valid phone number'
    ),
});

export type RegisterFormData = z.infer<typeof registerSchema>;

/**
 * Profile update validation schema
 */
export const profileSchema = z.object({
  fullName: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(100, 'Name cannot exceed 100 characters'),
  phone: z
    .string()
    .optional()
    .refine(
      (val) => !val || /^\+?[0-9]{10,15}$/.test(val),
      'Please enter a valid phone number'
    ),
  address: z
    .string()
    .max(200, 'Address cannot exceed 200 characters')
    .optional(),
});

export type ProfileFormData = z.infer<typeof profileSchema>;
