import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { TableProvider } from "./context/TableContext";
import { AuthProvider } from "./context/AuthContext";
import { CartProvider } from "./context/CartContext";

// Customer Pages (Mobile UI)
import CustomerLogin from "./pages/customer/CustomerLogin";
import CustomerRegister from "./pages/customer/CustomerRegister";
import CustomerMenu from "./pages/customer/CustomerMenu";
import CustomerOrders from "./pages/customer/CustomerOrders";
import CustomerProfile from "./pages/customer/CustomerProfile";
import CustomerTableSelection from "./pages/customer/CustomerTableSelection";

// Admin Pages (Desktop UI)
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import AdminMenuPage from "./pages/admin/AdminMenuPage";
import AdminStaffPage from "./pages/admin/AdminStaffPage";
import AdminOrdersPage from "./pages/admin/AdminOrdersPage";

// Kitchen Pages (Desktop UI)
import KitchenDisplayPage from "./pages/kitchen/KitchenDisplayPage";

// Error Pages
import { NotFound, Unauthorized } from "./pages/errors/ErrorPages";

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <TableProvider>
          <CartProvider>
            <Routes>
              {/* Customer Routes (Mobile UI) */}
              <Route path="/" element={<CustomerLogin />} />
              <Route path="/login" element={<CustomerLogin />} />
              <Route path="/register" element={<CustomerRegister />} />
              <Route path="/menu" element={<CustomerMenu />} />
              <Route path="/order" element={<CustomerOrders />} />
              <Route path="/profile" element={<CustomerProfile />} />
              <Route path="/table-select" element={<CustomerTableSelection />} />

              {/* Admin Routes (Desktop UI) */}
              <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
              <Route path="/admin/menu" element={<AdminMenuPage />} />
              <Route path="/admin/staff" element={<AdminStaffPage />} />
              <Route path="/admin/orders" element={<AdminOrdersPage />} />

              {/* Kitchen Routes (Desktop UI) */}
              <Route path="/kitchen" element={<KitchenDisplayPage />} />

              {/* Error Routes */}
              <Route path="/unauthorized" element={<Unauthorized />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </CartProvider>
        </TableProvider>
      </AuthProvider>
    </Router>
  );
}