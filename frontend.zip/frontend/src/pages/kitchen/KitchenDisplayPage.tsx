import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_ORDERS, formatTimeAgo, Order } from '../../services/mockData';

export default function KitchenDisplayPage() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [isAutoRefresh, setIsAutoRefresh] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const user = JSON.parse(localStorage.getItem('mockUser') || 'null');

  // Auto-refresh every 30 seconds
  useEffect(() => {
    if (!isAutoRefresh) return;
    
    const interval = setInterval(() => {
      setLastRefresh(new Date());
    }, 30000);
    
    return () => clearInterval(interval);
  }, [isAutoRefresh]);

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('mockUser');
    navigate('/login');
  };

  const pendingOrders = orders.filter(o => o.status === 'PENDING');
  const preparingOrders = orders.filter(o => o.status === 'PREPARING');
  const readyOrders = orders.filter(o => o.status === 'READY');

  const handleStartPrep = (orderId: number) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId 
        ? { ...order, status: 'PREPARING' as const, updatedAt: new Date().toISOString() }
        : order
    ));
  };

  const handleMarkReady = (orderId: number) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId 
        ? { ...order, status: 'READY' as const, updatedAt: new Date().toISOString() }
        : order
    ));
  };

  const handleMarkDelivered = (orderId: number) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId 
        ? { ...order, status: 'DELIVERED' as const, updatedAt: new Date().toISOString() }
        : order
    ));
  };

  const OrderCard = ({ order, actionLabel, onAction, actionColor }: { 
    order: Order; 
    actionLabel: string; 
    onAction: () => void;
    actionColor: string;
  }) => {
    const timeSinceCreated = formatTimeAgo(order.createdAt);
    const isUrgent = Date.now() - new Date(order.createdAt).getTime() > 10 * 60 * 1000; // 10 mins
    
    return (
      <div className={`card-elevated overflow-hidden animate-scale-in ${isUrgent ? 'order-card-urgent ring-2 ring-red-400' : ''}`}>
        {/* Header */}
        <div className={`px-5 py-4 ${isUrgent ? 'bg-gradient-to-r from-red-600 to-rose-600' : 'bg-gradient-to-r from-gray-800 to-gray-900'} text-white`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-xl tracking-wide">#{order.orderId.split('-')[1]?.slice(-6)}</span>
            <span className="text-sm bg-white/20 px-3 py-1 rounded-full font-medium">{order.tableName}</span>
          </div>
          <div className="flex items-center justify-between text-sm mt-2 opacity-90">
            <span className="flex items-center gap-1.5">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {timeSinceCreated}
            </span>
            {isUrgent && (
              <span className="flex items-center gap-1 animate-pulse font-semibold">
                <span className="text-lg">⚠️</span> URGENT
              </span>
            )}
          </div>
        </div>
        
        {/* Items */}
        <div className="p-5 bg-gradient-to-b from-white to-gray-50/50">
          <div className="space-y-3">
            {order.items.map((item, idx) => (
              <div key={`item-${order.id}-${idx}`} className="flex items-start gap-3 p-2 rounded-lg hover:bg-white transition-colors">
                <span className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 text-white rounded-xl flex items-center justify-center font-bold text-sm shadow-lg shadow-indigo-500/20">
                  {item.quantity}x
                </span>
                <div className="flex-1 pt-1">
                  <p className="font-semibold text-gray-900">{item.name}</p>
                  {item.notes && (
                    <p className="text-sm text-amber-600 mt-1 flex items-center gap-1.5 font-medium">
                      <span className="text-base">📝</span> {item.notes}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Action */}
        <div className="p-4 bg-gray-50 border-t border-gray-100">
          <button
            onClick={onAction}
            className={`w-full py-3.5 rounded-xl font-bold text-white transition-all duration-200 active:scale-[0.98] shadow-lg ${actionColor}`}
          >
            {actionLabel}
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-gray-100 to-slate-200">
      {/* Header */}
      <header className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white sticky top-0 z-40 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center text-2xl shadow-lg shadow-orange-500/30">
                🍳
              </div>
              <div>
                <span className="font-bold text-2xl tracking-tight">Kitchen Display</span>
                <p className="text-sm text-gray-400">Real-time order tracking</p>
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-3">
                <span className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 rounded-xl font-bold text-black shadow-lg shadow-amber-500/30">
                  {pendingOrders.length} Pending
                </span>
                <span className="px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl font-bold shadow-lg shadow-blue-500/30">
                  {preparingOrders.length} In Progress
                </span>
                <span className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-500 rounded-xl font-bold shadow-lg shadow-emerald-500/30">
                  {readyOrders.length} Ready
                </span>
              </div>
              
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsAutoRefresh(!isAutoRefresh)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    isAutoRefresh 
                      ? 'bg-emerald-600 shadow-lg shadow-emerald-500/30' 
                      : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                >
                  <span className={`text-lg ${isAutoRefresh ? 'animate-spin' : ''}`}>🔄</span>
                  {isAutoRefresh ? 'Auto-refresh ON' : 'Auto-refresh OFF'}
                </button>
                
                <div className="text-right">
                  <p className="font-semibold">{user?.fullName || 'Kitchen Staff'}</p>
                  <p className="text-xs text-gray-400">Last refresh: {lastRefresh.toLocaleTimeString()}</p>
                </div>
                
                <button
                  onClick={handleLogout}
                  className="btn-danger py-2"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content - 3 Column Layout */}
      <main className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Pending Column */}
          <div className="animate-fade-in stagger-1">
            <div className="flex items-center gap-3 mb-5 p-4 bg-gradient-to-r from-amber-100 to-yellow-50 rounded-2xl border border-amber-200/50">
              <div className="w-5 h-5 bg-gradient-to-r from-amber-500 to-yellow-500 rounded-full shadow-lg shadow-amber-500/30"></div>
              <h2 className="text-xl font-bold text-gray-900">PENDING</h2>
              <span className="ml-auto bg-amber-500 text-white px-4 py-1.5 rounded-xl text-sm font-bold shadow-lg shadow-amber-500/25">
                {pendingOrders.length}
              </span>
            </div>
            
            <div className="space-y-4">
              {pendingOrders.length === 0 ? (
                <div className="card-elevated p-10 text-center">
                  <div className="text-5xl mb-3 animate-float">✨</div>
                  <p className="text-gray-500 font-medium">All caught up!</p>
                  <p className="text-sm text-gray-400 mt-1">No pending orders</p>
                </div>
              ) : (
                pendingOrders.map(order => (
                  <OrderCard
                    key={order.id}
                    order={order}
                    actionLabel="🍳 Start Preparing"
                    onAction={() => handleStartPrep(order.id)}
                    actionColor="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 shadow-amber-500/30"
                  />
                ))
              )}
            </div>
          </div>

          {/* Preparing Column */}
          <div className="animate-fade-in stagger-2">
            <div className="flex items-center gap-3 mb-5 p-4 bg-gradient-to-r from-blue-100 to-indigo-50 rounded-2xl border border-blue-200/50">
              <div className="w-5 h-5 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full animate-pulse shadow-lg shadow-blue-500/30"></div>
              <h2 className="text-xl font-bold text-gray-900">IN PROGRESS</h2>
              <span className="ml-auto bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-4 py-1.5 rounded-xl text-sm font-bold shadow-lg shadow-blue-500/25">
                {preparingOrders.length}
              </span>
            </div>
            
            <div className="space-y-4">
              {preparingOrders.length === 0 ? (
                <div className="card-elevated p-10 text-center">
                  <div className="text-5xl mb-3 animate-float">👨‍🍳</div>
                  <p className="text-gray-500 font-medium">Kitchen ready</p>
                  <p className="text-sm text-gray-400 mt-1">No orders in progress</p>
                </div>
              ) : (
                preparingOrders.map(order => (
                  <OrderCard
                    key={order.id}
                    order={order}
                    actionLabel="✅ Mark Ready"
                    onAction={() => handleMarkReady(order.id)}
                    actionColor="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 shadow-blue-500/30"
                  />
                ))
              )}
            </div>
          </div>

          {/* Ready Column */}
          <div className="animate-fade-in stagger-3">
            <div className="flex items-center gap-3 mb-5 p-4 bg-gradient-to-r from-emerald-100 to-green-50 rounded-2xl border border-emerald-200/50">
              <div className="w-5 h-5 bg-gradient-to-r from-emerald-500 to-green-500 rounded-full shadow-lg shadow-emerald-500/30"></div>
              <h2 className="text-xl font-bold text-gray-900">READY TO SERVE</h2>
              <span className="ml-auto bg-gradient-to-r from-emerald-500 to-green-500 text-white px-4 py-1.5 rounded-xl text-sm font-bold shadow-lg shadow-emerald-500/25">
                {readyOrders.length}
              </span>
            </div>
            
            <div className="space-y-4">
              {readyOrders.length === 0 ? (
                <div className="card-elevated p-10 text-center">
                  <div className="text-5xl mb-3 animate-float">🍽️</div>
                  <p className="text-gray-500 font-medium">No orders ready</p>
                  <p className="text-sm text-gray-400 mt-1">Preparing in kitchen</p>
                </div>
              ) : (
                readyOrders.map(order => (
                  <OrderCard
                    key={order.id}
                    order={order}
                    actionLabel="🚀 Mark Delivered"
                    onAction={() => handleMarkDelivered(order.id)}
                    actionColor="bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 shadow-emerald-500/30"
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Sound notification simulation for new orders */}
      {pendingOrders.length > 0 && (
        <div className="fixed bottom-6 right-6 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-4 rounded-2xl shadow-2xl shadow-amber-500/30 animate-bounce-subtle flex items-center gap-3">
          <span className="text-2xl animate-pulse">🔔</span>
          <div>
            <p className="font-bold text-lg">{pendingOrders.length} order(s) waiting!</p>
            <p className="text-sm opacity-90">Tap pending orders to start</p>
          </div>
        </div>
      )}
    </div>
  );
}
