import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminLayout } from '../../components/AdminLayout';
import { MOCK_DASHBOARD_STATS, MOCK_ORDERS, formatPrice, formatTimeAgo, STATUS_COLORS } from '../../services/mockData';

export default function AdminDashboardPage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(MOCK_DASHBOARD_STATS);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    // Simulate stats update
    setStats({
      ...MOCK_DASHBOARD_STATS,
      todayRevenue: MOCK_DASHBOARD_STATS.todayRevenue + Math.floor(Math.random() * 1000),
      activeOrders: MOCK_ORDERS.filter(o => !['DELIVERED', 'CANCELLED'].includes(o.status)).length,
    });
    setIsRefreshing(false);
  };

  // Get recent orders (last 5)
  const recentOrders = MOCK_ORDERS.slice(0, 5);

  const statCards = [
    {
      label: "Today's Revenue",
      value: formatPrice(stats.todayRevenue),
      icon: '💰',
      color: 'bg-green-500',
      change: '+12%',
    },
    {
      label: 'Active Orders',
      value: stats.activeOrders,
      icon: '🛒',
      color: 'bg-blue-500',
      change: `${MOCK_ORDERS.filter(o => o.status === 'PENDING').length} pending`,
    },
    {
      label: 'Total Customers',
      value: stats.totalCustomers,
      icon: '👥',
      color: 'bg-purple-500',
      change: '+5 today',
    },
    {
      label: 'Pending Orders',
      value: MOCK_ORDERS.filter(o => o.status === 'PENDING').length,
      icon: '⏳',
      color: 'bg-yellow-500',
      change: 'Needs attention',
    },
  ];

  return (
    <AdminLayout>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="animate-fade-in">
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Dashboard</h1>
            <p className="text-gray-500 mt-1">Welcome back! Here's what's happening today.</p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="btn-secondary flex items-center gap-2"
          >
            <span className={`text-lg ${isRefreshing ? 'animate-spin' : ''}`}>🔄</span>
            Refresh
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {statCards.map((stat, idx) => (
            <div 
              key={`stat-${idx}`} 
              className={`card-elevated p-6 animate-slide-up stagger-${idx + 1} relative overflow-hidden group hover:scale-[1.02] transition-transform duration-300`}
            >
              {/* Background gradient accent */}
              <div className={`absolute top-0 right-0 w-32 h-32 ${stat.color} opacity-5 rounded-full blur-2xl -mr-10 -mt-10 group-hover:opacity-10 transition-opacity`} />
              
              <div className="flex items-center justify-between mb-4 relative">
                <div className={`w-14 h-14 ${stat.color} rounded-2xl flex items-center justify-center text-2xl shadow-lg`}>
                  {stat.icon}
                </div>
                <span className="text-xs font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">{stat.change}</span>
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
              <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="card-elevated p-6 mb-8 animate-slide-up stagger-5">
          <h2 className="text-lg font-bold text-gray-900 mb-5">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              onClick={() => navigate('/admin/menu')}
              className="group flex items-center gap-4 p-5 bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100/50 rounded-2xl hover:from-indigo-100 hover:to-purple-100 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
            >
              <span className="text-3xl group-hover:animate-bounce-subtle">🍽️</span>
              <div className="text-left">
                <p className="font-semibold text-gray-900">Menu Management</p>
                <p className="text-sm text-gray-500">Add, edit menu items</p>
              </div>
            </button>
            <button
              onClick={() => navigate('/admin/staff')}
              className="group flex items-center gap-4 p-5 bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-100/50 rounded-2xl hover:from-emerald-100 hover:to-teal-100 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
            >
              <span className="text-3xl group-hover:animate-bounce-subtle">👥</span>
              <div className="text-left">
                <p className="font-semibold text-gray-900">Staff Management</p>
                <p className="text-sm text-gray-500">Manage staff accounts</p>
              </div>
            </button>
            <button
              onClick={() => navigate('/kitchen')}
              className="group flex items-center gap-4 p-5 bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-100/50 rounded-2xl hover:from-amber-100 hover:to-orange-100 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
            >
              <span className="text-3xl group-hover:animate-bounce-subtle">🍳</span>
              <div className="text-left">
                <p className="font-semibold text-gray-900">Kitchen Display</p>
                <p className="text-sm text-gray-500">View kitchen orders</p>
              </div>
            </button>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="card-elevated overflow-hidden animate-slide-up stagger-6">
          <div className="flex items-center justify-between p-6 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-900">Recent Orders</h2>
            <button
              onClick={() => navigate('/admin/orders')}
              className="text-indigo-600 text-sm font-semibold hover:text-indigo-700 flex items-center gap-1 transition-colors"
            >
              View All
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-gray-50 to-gray-100/50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Order ID</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Table</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Items</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Total</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {recentOrders.map((order) => {
                  const statusStyle = STATUS_COLORS[order.status];
                  return (
                    <tr key={order.id} className="hover:bg-indigo-50/30 transition-colors">
                      <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                        #{order.orderId.split('-')[1]?.slice(-6)}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600 font-medium">{order.tableName}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        <span className="bg-gray-100 px-2 py-1 rounded-md font-medium">
                          {order.items.reduce((sum, item) => sum + item.quantity, 0)} items
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm font-bold text-gradient">
                        {formatPrice(order.totalAmount)}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1.5 rounded-full text-xs font-semibold ${statusStyle.bg} ${statusStyle.text} shadow-sm`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {formatTimeAgo(order.createdAt)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
