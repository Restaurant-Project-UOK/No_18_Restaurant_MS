import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTable } from '../../context/TableContext';
import { MOCK_TABLES } from '../../services/mockData';

export default function CustomerTableSelection() {
  const navigate = useNavigate();
  const { tableId, setTableId } = useTable();
  const [selectedTableId, setSelectedTableId] = useState<string | null>(tableId);

  const handleConfirm = () => {
    if (selectedTableId) {
      setTableId(selectedTableId);
      navigate('/menu');
    }
  };

  const handleSkip = () => {
    navigate('/menu');
  };

  // Sort tables by ID
  const sortedTables = [...MOCK_TABLES].sort((a, b) => a.id - b.id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4">
      <div className="max-w-2xl mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🪑</div>
          <h1 className="text-3xl font-bold text-white mb-2">Select Your Table</h1>
          <p className="text-white/80">Choose your table to start ordering</p>
        </div>

        {/* Tables Grid */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            {sortedTables.map((table) => {
              const isSelected = selectedTableId === String(table.id);
              const isOccupied = table.isOccupied;
              
              return (
                <button
                  key={table.id}
                  onClick={() => !isOccupied && setSelectedTableId(String(table.id))}
                  disabled={isOccupied}
                  className={`relative p-4 rounded-xl border-2 transition-all ${
                    isOccupied
                      ? 'border-gray-200 bg-gray-100 cursor-not-allowed opacity-60'
                      : isSelected
                      ? 'border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500 ring-offset-2'
                      : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50'
                  }`}
                >
                  {/* Table Icon */}
                  <div className="text-3xl mb-2">
                    {isOccupied ? '🔴' : isSelected ? '🟢' : '🪑'}
                  </div>
                  
                  {/* Table Info */}
                  <p className={`font-semibold ${isSelected ? 'text-indigo-700' : 'text-gray-900'}`}>
                    {table.name}
                  </p>
                  <p className="text-sm text-gray-500">
                    {table.capacity} seats
                  </p>
                  
                  {/* Status Badge */}
                  {isOccupied && (
                    <span className="absolute top-2 right-2 px-2 py-0.5 bg-red-100 text-red-600 text-xs rounded-full">
                      Occupied
                    </span>
                  )}
                  {isSelected && !isOccupied && (
                    <span className="absolute top-2 right-2 text-indigo-600">✓</span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center gap-6 mb-6 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-green-500"></span>
              <span>Available</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500"></span>
              <span>Occupied</span>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <button
              onClick={handleConfirm}
              disabled={!selectedTableId}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {selectedTableId ? `Confirm Table ${selectedTableId}` : 'Select a Table'}
            </button>
            
            <button
              onClick={handleSkip}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              Browse Menu Only
            </button>
          </div>

          {/* Info */}
          <p className="text-center text-sm text-gray-500 mt-4">
            You can change your table later from the menu page
          </p>
        </div>

        {/* Back to Login */}
        <div className="text-center mt-6">
          <button
            onClick={() => navigate('/login')}
            className="text-white/80 hover:text-white"
          >
            ← Back to Login
          </button>
        </div>
      </div>
    </div>
  );
}
