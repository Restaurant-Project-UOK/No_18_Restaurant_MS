import { useState } from 'react';
import { CustomerHeader } from '../../components/CustomerHeader';
import { MOCK_ORDERS, formatPrice, formatTimeAgo, STATUS_COLORS, Order } from '../../services/mockData';

export default function CustomerOrders() {
  const [orders] = useState<Order[]>(MOCK_ORDERS);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Filter orders by the current user (mock: userId 1)
  const userOrders = orders.filter(order => order.userId === 1);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING': return '⏳';
      case 'PREPARING': return '🔄';
      case 'READY': return '✅';
      case 'DELIVERED': return '🎉';
      case 'CANCELLED': return '❌';
      default: return '📋';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <CustomerHeader showCart={false} />

      <div className="p-4 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Your Orders</h1>

        {userOrders.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📋</div>
            <p className="text-gray-500 mb-4">No orders yet</p>
            <a href="/menu" className="text-indigo-600 font-medium hover:text-indigo-700">
              Browse Menu
            </a>
          </div>
        ) : (
          <div className="space-y-4">
            {userOrders.map((order) => {
              const statusStyle = STATUS_COLORS[order.status];
              
              return (
                <div
                  key={order.id}
                  className="bg-white rounded-xl shadow-sm overflow-hidden"
                >
                  {/* Order Header */}
                  <div
                    className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => setSelectedOrder(selectedOrder?.id === order.id ? null : order)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="font-semibold text-gray-900">#{order.orderId.split('-')[1]?.slice(-6)}</span>
                        <span className="mx-2 text-gray-300">•</span>
                        <span className="text-sm text-gray-500">{order.tableName}</span>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusStyle.bg} ${statusStyle.text}`}>
                        {getStatusIcon(order.status)} {order.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">{formatTimeAgo(order.createdAt)}</span>
                      <span className="font-semibold text-green-600">{formatPrice(order.totalAmount)}</span>
                    </div>

                    {/* Preview items */}
                    <div className="mt-2 text-sm text-gray-600">
                      {order.items.map((item, idx) => (
                        <span key={idx}>
                          {item.quantity}x {item.name}
                          {idx < order.items.length - 1 && ', '}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {selectedOrder?.id === order.id && (
                    <div className="border-t bg-gray-50 p-4">
                      <h4 className="font-medium text-gray-900 mb-3">Order Details</h4>
                      
                      <div className="space-y-2 mb-4">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between text-sm">
                            <div>
                              <span className="font-medium">{item.quantity}x</span> {item.name}
                              {item.notes && (
                                <span className="text-gray-500 ml-2">({item.notes})</span>
                              )}
                            </div>
                            <span className="text-gray-600">{formatPrice(item.subtotal)}</span>
                          </div>
                        ))}
                      </div>

                      <div className="border-t pt-3 space-y-1 text-sm">
                        <div className="flex justify-between text-gray-600">
                          <span>Subtotal</span>
                          <span>{formatPrice(order.subtotal)}</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                          <span>Service Fee (10%)</span>
                          <span>{formatPrice(order.serviceFee)}</span>
                        </div>
                        <div className="flex justify-between font-semibold text-gray-900 pt-2 border-t mt-2">
                          <span>Total</span>
                          <span>{formatPrice(order.totalAmount)}</span>
                        </div>
                      </div>

                      {/* Order Progress */}
                      <div className="mt-4 pt-4 border-t">
                        <h4 className="font-medium text-gray-900 mb-3">Order Progress</h4>
                        <div className="flex items-center justify-between">
                          {['PENDING', 'PREPARING', 'READY', 'DELIVERED'].map((status, idx) => {
                            const statusOrder = ['PENDING', 'PREPARING', 'READY', 'DELIVERED'];
                            const currentIdx = statusOrder.indexOf(order.status);
                            const isCompleted = idx <= currentIdx;
                            const isCurrent = idx === currentIdx;
                            
                            return (
                              <div key={status} className="flex flex-col items-center flex-1">
                                <div
                                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                    isCompleted
                                      ? isCurrent
                                        ? 'bg-indigo-600 text-white'
                                        : 'bg-green-500 text-white'
                                      : 'bg-gray-200 text-gray-400'
                                  }`}
                                >
                                  {isCompleted && !isCurrent ? '✓' : idx + 1}
                                </div>
                                <span className={`text-xs mt-1 ${isCurrent ? 'text-indigo-600 font-medium' : 'text-gray-500'}`}>
                                  {status}
                                </span>
                                {idx < 3 && (
                                  <div className={`hidden sm:block absolute w-12 h-0.5 ml-24 ${isCompleted ? 'bg-green-500' : 'bg-gray-200'}`} />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
