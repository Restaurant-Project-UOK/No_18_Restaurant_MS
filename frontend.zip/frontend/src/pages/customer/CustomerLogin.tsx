import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MOCK_USERS, generateMockToken } from '../../services/mockData';

export default function CustomerLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // Mock authentication
    const userRecord = MOCK_USERS[email.toLowerCase()];
    
    if (userRecord && userRecord.password === password) {
      const token = generateMockToken(userRecord.user);
      
      // Store tokens and user
      localStorage.setItem('accessToken', token);
      localStorage.setItem('refreshToken', 'mock-refresh-token');
      localStorage.setItem('mockUser', JSON.stringify(userRecord.user));
      
      // Redirect based on role
      switch (userRecord.user.role) {
        case 2: // Admin
          navigate('/admin/dashboard');
          break;
        case 3: // Kitchen
          navigate('/kitchen');
          break;
        default: // Customer
          navigate('/menu');
      }
    } else {
      setError('Invalid email or password');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-primary flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      
      <div className="w-full max-w-md relative z-10 animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="text-7xl mb-4 animate-float">🍽️</div>
          <h1 className="text-4xl font-bold text-white tracking-tight">No.18 Restaurant</h1>
          <p className="text-white/80 mt-2 text-lg">Welcome back!</p>
        </div>

        {/* Login Card */}
        <div className="glass rounded-3xl shadow-2xl p-8 animate-slide-up stagger-1">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Sign In</h2>
          
          {error && (
            <div className="bg-red-50 text-red-600 px-4 py-3 rounded-xl mb-4 flex items-center gap-2 animate-scale-in">
              <svg className="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input pl-12"
                placeholder="Email address"
                required
              />
            </div>

            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input pl-12"
                placeholder="Password"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Signing in...
                </span>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Don't have an account?{' '}
              <Link to="/register" className="text-indigo-600 font-semibold hover:text-indigo-700 transition-colors">
                Register
              </Link>
            </p>
          </div>

          {/* Test Credentials */}
          <div className="mt-8 pt-6 border-t border-gray-200/50">
            <p className="text-xs text-gray-500 text-center mb-3 font-medium uppercase tracking-wider">Test Credentials</p>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between bg-gradient-to-r from-indigo-50 to-purple-50 px-4 py-3 rounded-xl border border-indigo-100/50">
                <span className="text-indigo-600 font-medium">👤 Customer</span>
                <span className="font-mono text-gray-700 text-[11px]">customer@test.com / password123</span>
              </div>
              <div className="flex items-center justify-between bg-gradient-to-r from-amber-50 to-orange-50 px-4 py-3 rounded-xl border border-amber-100/50">
                <span className="text-amber-600 font-medium">👑 Admin</span>
                <span className="font-mono text-gray-700 text-[11px]">admin@test.com / admin123</span>
              </div>
              <div className="flex items-center justify-between bg-gradient-to-r from-emerald-50 to-teal-50 px-4 py-3 rounded-xl border border-emerald-100/50">
                <span className="text-emerald-600 font-medium">👨‍🍳 Kitchen</span>
                <span className="font-mono text-gray-700 text-[11px]">kitchen@test.com / kitchen123</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
