import { useState, useMemo } from 'react';
import { CustomerHeader } from '../../components/CustomerHeader';
import { useCart } from '../../context/CartContext';
import { MOCK_MENU, MENU_CATEGORIES, formatPrice, MenuItem } from '../../services/mockData';

export default function Menu() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const { addToCart, cartItems } = useCart();
  const [addedItemId, setAddedItemId] = useState<number | null>(null);

  const filteredMenu = useMemo(() => {
    return MOCK_MENU.filter(item => {
      if (!item.isActive) return false;
      
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           item.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleAddToCart = (item: MenuItem) => {
    addToCart(item, 1);
    setAddedItemId(item.id);
    setTimeout(() => setAddedItemId(null), 1000);
  };

  const getItemQuantityInCart = (itemId: number) => {
    const cartItem = cartItems.find(item => item.id === itemId);
    return cartItem?.quantity || 0;
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <CustomerHeader />
      
      {/* Search & Filter Section */}
      <div className="sticky top-[57px] glass z-30 px-4 py-4 border-b border-gray-100/50">
        {/* Search Bar */}
        <div className="relative mb-4">
          <input
            type="text"
            placeholder="Search delicious dishes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white/80 border border-gray-200/50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-400 focus:bg-white transition-all shadow-sm"
          />
          <svg
            className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {MENU_CATEGORIES.filter(cat => cat !== 'Appetizers' || MOCK_MENU.some(item => item.category === cat && item.isActive)).map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-5 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-lg shadow-indigo-500/25'
                  : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200/50 hover:border-gray-300'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Grid */}
      <div className="p-4 pb-8">
        {filteredMenu.length === 0 ? (
          <div className="text-center py-16 animate-fade-in">
            <div className="text-7xl mb-4 animate-bounce-subtle">🍽️</div>
            <p className="text-gray-500 text-lg">No dishes found</p>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="mt-4 btn-secondary text-sm"
              >
                Clear search
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filteredMenu.map((item, index) => {
              const quantityInCart = getItemQuantityInCart(item.id);
              const isJustAdded = addedItemId === item.id;
              
              return (
                <div
                  key={item.id}
                  className={`card-interactive animate-fade-in stagger-${Math.min(index % 6 + 1, 6)}`}
                >
                  {/* Image */}
                  <div className="relative h-44 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden group">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x200?text=🍽️';
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                    {quantityInCart > 0 && (
                      <div className="absolute top-3 right-3 bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg shadow-indigo-500/30 animate-scale-in">
                        {quantityInCart} in cart
                      </div>
                    )}
                    <div className="absolute top-3 left-3 glass text-xs font-semibold px-3 py-1.5 rounded-full text-gray-700">
                      {item.category}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-5">
                    <h3 className="font-bold text-gray-900 mb-1.5 text-lg">{item.name}</h3>
                    <p className="text-sm text-gray-500 line-clamp-2 mb-4 leading-relaxed">{item.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-xl font-bold text-gradient">{formatPrice(item.price)}</span>
                      <button
                        onClick={() => handleAddToCart(item)}
                        className={`px-5 py-2.5 rounded-xl font-semibold transition-all duration-200 active:scale-95 ${
                          isJustAdded
                            ? 'bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-lg shadow-emerald-500/25'
                            : 'bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-lg shadow-indigo-500/25 hover:shadow-xl hover:shadow-indigo-500/30'
                        }`}
                      >
                        {isJustAdded ? '✓ Added' : '+ Add'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
