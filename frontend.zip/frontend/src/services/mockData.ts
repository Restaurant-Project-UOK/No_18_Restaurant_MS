// Mock Data Service - For testing without backend connection

export interface User {
  id: number;
  email: string;
  fullName: string;
  phone: string;
  role: number; // 1 = Customer, 2 = Admin, 3 = Kitchen
  createdAt: string;
}

export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl: string;
  isActive: boolean;
  createdAt: string;
}

export interface OrderItem {
  menuItemId: number;
  name: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  notes?: string;
}

export interface Order {
  id: number;
  orderId: string;
  userId: number;
  tableId: number;
  tableName: string;
  status: 'PENDING' | 'PREPARING' | 'READY' | 'DELIVERED' | 'CANCELLED';
  items: OrderItem[];
  subtotal: number;
  serviceFee: number;
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Table {
  id: number;
  name: string;
  capacity: number;
  isOccupied: boolean;
}

export interface DashboardStats {
  todayRevenue: number;
  activeOrders: number;
  totalCustomers: number;
  pendingOrders: number;
}

// Test Users
export const MOCK_USERS: Record<string, { password: string; user: User }> = {
  'customer@test.com': {
    password: 'password123',
    user: {
      id: 1,
      email: 'customer@test.com',
      fullName: 'Test Customer',
      phone: '+94771234567',
      role: 1,
      createdAt: '2024-01-15T08:00:00Z',
    },
  },
  'admin@test.com': {
    password: 'admin123',
    user: {
      id: 2,
      email: 'admin@test.com',
      fullName: 'Admin User',
      phone: '+94772345678',
      role: 2,
      createdAt: '2024-01-10T08:00:00Z',
    },
  },
  'kitchen@test.com': {
    password: 'kitchen123',
    user: {
      id: 3,
      email: 'kitchen@test.com',
      fullName: 'Kitchen Staff',
      phone: '+94773456789',
      role: 3,
      createdAt: '2024-01-12T08:00:00Z',
    },
  },
};

// Menu Items
export const MOCK_MENU: MenuItem[] = [
  {
    id: 1,
    name: 'Margherita Pizza',
    description: 'Classic Italian pizza with tomato sauce, mozzarella, and fresh basil',
    price: 1200,
    category: 'Pizza',
    imageUrl: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 2,
    name: 'Classic Burger',
    description: 'Juicy beef patty with lettuce, tomato, cheese, and special sauce',
    price: 800,
    category: 'Burgers',
    imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 3,
    name: 'Spaghetti Carbonara',
    description: 'Creamy pasta with bacon, egg, and parmesan cheese',
    price: 1000,
    category: 'Pasta',
    imageUrl: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 4,
    name: 'Caesar Salad',
    description: 'Fresh romaine lettuce with caesar dressing, croutons, and parmesan',
    price: 600,
    category: 'Salads',
    imageUrl: 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 5,
    name: 'Chicken Noodles',
    description: 'Stir-fried noodles with chicken and vegetables',
    price: 750,
    category: 'Asian',
    imageUrl: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 6,
    name: 'Sushi Combo',
    description: 'Assorted sushi platter with salmon, tuna, and shrimp (12 pcs)',
    price: 2500,
    category: 'Japanese',
    imageUrl: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 7,
    name: 'Chocolate Lava Cake',
    description: 'Warm chocolate cake with molten center, served with vanilla ice cream',
    price: 500,
    category: 'Desserts',
    imageUrl: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 8,
    name: 'Fresh Lime Soda',
    description: 'Refreshing lime juice with soda water',
    price: 200,
    category: 'Beverages',
    imageUrl: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=300&h=200&fit=crop',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 9,
    name: 'BBQ Chicken Wings',
    description: 'Crispy chicken wings with BBQ sauce',
    price: 900,
    category: 'Appetizers',
    imageUrl: 'https://images.unsplash.com/photo-1608039755401-742074f0548d?w=300&h=200&fit=crop',
    isActive: false,
    createdAt: '2024-01-01T00:00:00Z',
  },
];

// Tables
export const MOCK_TABLES: Table[] = [
  { id: 1, name: 'Table-1', capacity: 2, isOccupied: false },
  { id: 2, name: 'Table-2', capacity: 4, isOccupied: true },
  { id: 3, name: 'Table-3', capacity: 4, isOccupied: false },
  { id: 4, name: 'Table-4', capacity: 6, isOccupied: false },
  { id: 5, name: 'Table-5', capacity: 6, isOccupied: true },
  { id: 6, name: 'Table-6', capacity: 8, isOccupied: false },
  { id: 7, name: 'Table-7', capacity: 2, isOccupied: false },
  { id: 8, name: 'Table-8', capacity: 4, isOccupied: false },
];

// Helper to generate order ID
const generateOrderId = () => `ORD-${Date.now()}${Math.floor(Math.random() * 1000)}`;

// Sample Orders
export const MOCK_ORDERS: Order[] = [
  {
    id: 1235,
    orderId: generateOrderId(),
    userId: 1,
    tableId: 8,
    tableName: 'Table-8',
    status: 'PENDING',
    items: [
      { menuItemId: 4, name: 'Caesar Salad', quantity: 1, unitPrice: 600, subtotal: 600 },
    ],
    subtotal: 600,
    serviceFee: 60,
    totalAmount: 660,
    createdAt: new Date(Date.now() - 2 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 60000).toISOString(),
  },
  {
    id: 1234,
    orderId: generateOrderId(),
    userId: 1,
    tableId: 5,
    tableName: 'Table-5',
    status: 'PREPARING',
    items: [
      { menuItemId: 1, name: 'Margherita Pizza', quantity: 2, unitPrice: 1200, subtotal: 2400, notes: 'Extra cheese' },
      { menuItemId: 2, name: 'Classic Burger', quantity: 1, unitPrice: 800, subtotal: 800 },
    ],
    subtotal: 3200,
    serviceFee: 320,
    totalAmount: 3520,
    createdAt: new Date(Date.now() - 5 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 60000).toISOString(),
  },
  {
    id: 1233,
    orderId: generateOrderId(),
    userId: 2,
    tableId: 2,
    tableName: 'Table-2',
    status: 'READY',
    items: [
      { menuItemId: 3, name: 'Spaghetti Carbonara', quantity: 1, unitPrice: 1000, subtotal: 1000 },
      { menuItemId: 8, name: 'Fresh Lime Soda', quantity: 2, unitPrice: 200, subtotal: 400 },
    ],
    subtotal: 1400,
    serviceFee: 140,
    totalAmount: 1540,
    createdAt: new Date(Date.now() - 8 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 60000).toISOString(),
  },
  {
    id: 1232,
    orderId: generateOrderId(),
    userId: 1,
    tableId: 3,
    tableName: 'Table-3',
    status: 'PREPARING',
    items: [
      { menuItemId: 6, name: 'Sushi Combo', quantity: 1, unitPrice: 2500, subtotal: 2500, notes: 'No wasabi' },
      { menuItemId: 5, name: 'Chicken Noodles', quantity: 2, unitPrice: 750, subtotal: 1500 },
    ],
    subtotal: 4000,
    serviceFee: 400,
    totalAmount: 4400,
    createdAt: new Date(Date.now() - 10 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 5 * 60000).toISOString(),
  },
  {
    id: 1231,
    orderId: generateOrderId(),
    userId: 1,
    tableId: 1,
    tableName: 'Table-1',
    status: 'PREPARING',
    items: [
      { menuItemId: 3, name: 'Spaghetti Carbonara', quantity: 3, unitPrice: 1000, subtotal: 3000 },
    ],
    subtotal: 3000,
    serviceFee: 300,
    totalAmount: 3300,
    createdAt: new Date(Date.now() - 15 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 10 * 60000).toISOString(),
  },
  {
    id: 1230,
    orderId: generateOrderId(),
    userId: 1,
    tableId: 5,
    tableName: 'Table-5',
    status: 'DELIVERED',
    items: [
      { menuItemId: 3, name: 'Spaghetti Carbonara', quantity: 1, unitPrice: 1000, subtotal: 1000 },
    ],
    subtotal: 1000,
    serviceFee: 100,
    totalAmount: 1100,
    createdAt: new Date(Date.now() - 60 * 60000).toISOString(),
    updatedAt: new Date(Date.now() - 30 * 60000).toISOString(),
  },
];

// Staff Members (for admin)
export interface StaffMember {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  role: number;
  roleName: string;
  isActive: boolean;
  createdAt: string;
}

export const MOCK_STAFF: StaffMember[] = [
  {
    id: 2,
    fullName: 'Admin User',
    email: 'admin@test.com',
    phone: '+94772345678',
    role: 2,
    roleName: 'Admin',
    isActive: true,
    createdAt: '2024-01-10T08:00:00Z',
  },
  {
    id: 3,
    fullName: 'Kitchen Staff',
    email: 'kitchen@test.com',
    phone: '+94773456789',
    role: 3,
    roleName: 'Kitchen',
    isActive: true,
    createdAt: '2024-01-12T08:00:00Z',
  },
  {
    id: 4,
    fullName: 'John Doe',
    email: 'john@test.com',
    phone: '+94774567890',
    role: 3,
    roleName: 'Kitchen',
    isActive: true,
    createdAt: '2024-01-20T08:00:00Z',
  },
  {
    id: 5,
    fullName: 'Jane Smith',
    email: 'jane@test.com',
    phone: '+94775678901',
    role: 2,
    roleName: 'Admin',
    isActive: false,
    createdAt: '2024-02-01T08:00:00Z',
  },
];

// Dashboard Stats
export const MOCK_DASHBOARD_STATS: DashboardStats = {
  todayRevenue: 45600,
  activeOrders: 12,
  totalCustomers: 156,
  pendingOrders: 3,
};

// Categories for filtering
export const MENU_CATEGORIES = [
  'All',
  'Pizza',
  'Burgers',
  'Pasta',
  'Salads',
  'Asian',
  'Japanese',
  'Desserts',
  'Beverages',
  'Appetizers',
];

// Role names
export const ROLE_NAMES: Record<number, string> = {
  1: 'Customer',
  2: 'Admin',
  3: 'Kitchen',
};

// Order status colors
export const STATUS_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  PENDING: { bg: 'bg-yellow-100', text: 'text-yellow-800', border: 'border-yellow-300' },
  PREPARING: { bg: 'bg-blue-100', text: 'text-blue-800', border: 'border-blue-300' },
  READY: { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-300' },
  DELIVERED: { bg: 'bg-gray-100', text: 'text-gray-800', border: 'border-gray-300' },
  CANCELLED: { bg: 'bg-red-100', text: 'text-red-800', border: 'border-red-300' },
};

// Helper function to format price in LKR
export const formatPrice = (price: number): string => `රු ${price.toLocaleString()}`;

// Helper function to format time ago
export const formatTimeAgo = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} min ago`;
  
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
};

// Generate mock JWT token
export const generateMockToken = (user: User): string => {
  const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = btoa(JSON.stringify({
    sub: String(user.id),
    email: user.email,
    role: user.role,
    exp: Math.floor(Date.now() / 1000) + 3600, // 1 hour
  }));
  const signature = btoa('mock-signature');
  return `${header}.${payload}.${signature}`;
};
