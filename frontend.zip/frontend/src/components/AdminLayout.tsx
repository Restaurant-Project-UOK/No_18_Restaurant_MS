import { useNavigate, useLocation } from 'react-router-dom';

interface AdminLayoutProps {
  children: React.ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const user = JSON.parse(localStorage.getItem('mockUser') || 'null');

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('mockUser');
    navigate('/login');
  };

  const navItems = [
    { path: '/admin/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/admin/menu', label: 'Menu Management', icon: '🍽️' },
    { path: '/admin/staff', label: 'Staff Management', icon: '👥' },
    { path: '/admin/orders', label: 'All Orders', icon: '📋' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Top Bar */}
      <header className="glass sticky top-0 z-40 border-b border-gray-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-18 py-4">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center text-xl shadow-lg shadow-indigo-500/25">
                🍽️
              </div>
              <div>
                <span className="font-bold text-xl text-gray-900 tracking-tight">No.18 Admin</span>
                <p className="text-xs text-gray-500">Restaurant Management</p>
              </div>
            </div>

            {/* User Info */}
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-semibold text-gray-900">{user?.fullName || 'Admin'}</p>
                <p className="text-xs text-indigo-600 font-medium">Administrator</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-xl flex items-center justify-center text-lg">
                👑
              </div>
              <button
                onClick={handleLogout}
                className="px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 rounded-xl transition-all hover:shadow-md"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-72 bg-white/80 backdrop-blur-lg shadow-xl min-h-[calc(100vh-72px)] sticky top-[72px] border-r border-gray-100/50">
          <nav className="p-5 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl text-left transition-all duration-200 ${
                  isActive(item.path)
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/25'
                    : 'text-gray-600 hover:bg-gray-50 hover:shadow-md'
                }`}
              >
                <span className={`text-2xl ${isActive(item.path) ? 'animate-bounce-subtle' : ''}`}>{item.icon}</span>
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="absolute bottom-6 left-5 right-5">
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-5 text-center border border-indigo-100/50">
              <div className="text-3xl mb-2">🍴</div>
              <p className="text-sm text-indigo-800 font-semibold">Restaurant System</p>
              <p className="text-xs text-indigo-600 mt-1">v1.0.0 (Demo Mode)</p>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
