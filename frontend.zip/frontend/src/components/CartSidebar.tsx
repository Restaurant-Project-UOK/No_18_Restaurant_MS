import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useTable } from '../context/TableContext';
import { formatPrice, MOCK_ORDERS, Order } from '../services/mockData';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const navigate = useNavigate();
  const { cartItems, removeFromCart, updateQuantity, getTotalPrice, clearCart } = useCart();
  const { tableId } = useTable();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  
  const subtotal = getTotalPrice();
  const serviceFee = Math.round(subtotal * 0.1);
  const total = subtotal + serviceFee;

  const handleCheckout = async () => {
    setIsCheckingOut(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Create mock order from cart items
    const newOrder: Order = {
      id: Math.floor(Math.random() * 10000),
      orderId: `ORD-${Date.now()}`,
      userId: 1,
      tableId: Number(tableId) || 1,
      tableName: `Table-${tableId || 1}`,
      status: 'PENDING',
      items: cartItems.map(item => ({
        menuItemId: item.id,
        name: item.name,
        quantity: item.quantity,
        unitPrice: item.price,
        subtotal: item.price * item.quantity,
        notes: item.notes,
      })),
      subtotal,
      serviceFee,
      totalAmount: total,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Add to mock orders (in memory)
    MOCK_ORDERS.unshift(newOrder);
    
    setIsCheckingOut(false);
    setCheckoutSuccess(true);
    
    // Clear cart and redirect
    setTimeout(() => {
      clearCart();
      setCheckoutSuccess(false);
      onClose();
      navigate('/order');
    }, 1500);
  };

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm transition-all z-50 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Escape' && onClose()}
      />

      {/* Sidebar */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 transform transition-all duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-indigo-50 to-purple-50">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Your Cart</h2>
              <p className="text-sm text-gray-500">{cartItems.length} item(s)</p>
            </div>
            <button
              onClick={onClose}
              className="p-2.5 text-gray-500 hover:text-gray-700 rounded-xl hover:bg-white/80 transition-all shadow-sm bg-white/50"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Success Message */}
          {checkoutSuccess && (
            <div className="p-6 bg-gradient-to-r from-emerald-500 to-green-500 text-white text-center animate-slide-up">
              <div className="text-4xl mb-3 animate-bounce-subtle">✅</div>
              <p className="font-bold text-lg">Order placed successfully!</p>
              <p className="text-sm opacity-90">Redirecting to your orders...</p>
            </div>
          )}

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-5 bg-gray-50/50">
            {cartItems.length === 0 ? (
              <div className="text-center py-16 animate-fade-in">
                <div className="text-7xl mb-4 animate-float">🛒</div>
                <p className="text-gray-500 text-lg font-medium">Your cart is empty</p>
                <p className="text-gray-400 text-sm mt-1">Add some delicious dishes!</p>
                <button
                  onClick={() => {
                    onClose();
                    navigate('/menu');
                  }}
                  className="mt-6 btn-primary"
                >
                  Browse Menu
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {cartItems.map((item, index) => (
                  <div key={item.id} className={`card-elevated p-4 animate-slide-up stagger-${Math.min(index + 1, 6)}`}>
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-semibold text-gray-900">{item.name}</h3>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-500 hover:text-red-700 text-sm font-medium hover:bg-red-50 px-2 py-1 rounded-lg transition-all"
                      >
                        Remove
                      </button>
                    </div>
                    
                    {item.notes && (
                      <p className="text-sm text-amber-600 mb-3 flex items-center gap-1.5 bg-amber-50 px-3 py-2 rounded-lg">
                        <span>📝</span> {item.notes}
                      </p>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-9 h-9 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center font-bold text-gray-600 transition-all active:scale-95"
                        >
                          -
                        </button>
                        <span className="w-10 text-center font-bold text-lg">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-9 h-9 rounded-xl bg-indigo-100 hover:bg-indigo-200 flex items-center justify-center font-bold text-indigo-600 transition-all active:scale-95"
                        >
                          +
                        </button>
                      </div>
                      <span className="font-bold text-lg text-gradient">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {cartItems.length > 0 && (
            <div className="border-t border-gray-100 p-5 space-y-4 bg-white">
              <div className="space-y-2">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span className="font-medium">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Service Fee (10%)</span>
                  <span className="font-medium">{formatPrice(serviceFee)}</span>
                </div>
                <div className="flex justify-between text-xl font-bold text-gray-900 pt-3 border-t border-dashed">
                  <span>Total</span>
                  <span className="text-gradient">{formatPrice(total)}</span>
                </div>
              </div>
              
              {tableId ? (
                <button
                  onClick={handleCheckout}
                  disabled={isCheckingOut || checkoutSuccess}
                  className="btn-primary w-full"
                >
                  {isCheckingOut ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Processing...
                    </span>
                  ) : (
                    `🚀 Place Order • ${formatPrice(total)}`
                  )}
                </button>
              ) : (
                <div className="text-center bg-amber-50 p-4 rounded-2xl border border-amber-200">
                  <p className="text-amber-700 text-sm mb-3 font-medium">⚠️ Please select a table first</p>
                  <button
                    onClick={() => {
                      onClose();
                      navigate('/table-select');
                    }}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white py-3 rounded-xl font-semibold hover:from-amber-600 hover:to-orange-600 transition-all shadow-lg shadow-amber-500/25"
                  >
                    🍽️ Select Table
                  </button>
                </div>
              )}
              
              <button
                onClick={clearCart}
                className="w-full btn-ghost text-red-600 hover:bg-red-50"
              >
                🗑️ Clear Cart
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
